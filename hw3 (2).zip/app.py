from flask import Flask,render_template, request
import os

app = Flask(__name__)
FILE_PATH = os.path.join(os.path.dirname(__file__), 'files')
sequences_input = ''
sequences_file = None
image_format = ''

@app.route('/')
def webSite():
    return render_template('index.html')

@app.route('/generate_logo', methods=['GET', 'POST'])
def generate_logo():
    if request.method == 'POST':
        print(request.files)
        # get input from form
        global sequences_input, sequences_file, image_format
        sequences_input = request.form['sequences-input']
        sequences_file = request.files['sequences-file']
        image_format = request.form['image-format']
        print(sequences_input, sequences_file, image_format)

        # save sequences file
        if sequences_file:
            sequences_file.save(os.path.join(FILE_PATH, 'sequences.txt'))

        return render_template('logo.html')
    else:
        return render_template('index.html')

def getInputData():
    global sequences_input, image_format
    return sequences_input, image_format

if __name__ == '__main__':
    app.run()