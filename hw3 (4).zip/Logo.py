import logomaker
import matplotlib.pyplot as plt
import os, matplotlib
# from Bio import SeqIO

def visualize_sequence_logo(sequences, save_path=None, image_format=None, show_img=False):
    # 產生 logo
    matrix = logomaker.alignment_to_matrix(sequences, to_type='counts')
    logo = logomaker.Logo(matrix, color_scheme='skylign_protein')
    logo.ax.set_ylim(0, len(sequences))

    # 直接顯示圖片，debug用
    if show_img: 
        plt.show()
        return
    
    # 儲存 logo
    plt_path = os.path.join(save_path, 'logo.' + image_format)
    plt.savefig(plt_path)

# sequences = []
# fasta_file = "test.fasta"
# for record in SeqIO.parse(fasta_file, "fasta"):
#     sequences.append(str(record.seq))
# visualize_sequence_logo(sequences)

if __name__ == '__main__':
    sequence = ['GDLGAGKTT', 'GDLGAGKTT', 'GPLGAGKTS', 'GDLGAGKTS', 'GDLGAGKTT', 'GDLGAGKTT', 'GEVGSGKTT', 'GELGAGKTT', 'GDLGAGKTT', 'GNLGAGKTT', 'GELGAGKTT', 'GTLGAGKTT', 'GDLGAGKTT', 'GDLGAGKTT', 'GDLGAGKTT', 'GDLGAGKTT', 'GDLGAGKTT']
    visualize_sequence_logo(sequence)
